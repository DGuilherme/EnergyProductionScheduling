# JSSP-problem-set-ZLP
A data set that measures the level of excellence of learning algorithms, automatically generated JSSP questions, including generated code and several examples
